// specifies additional routes for prerender
export const ROUTES = [];